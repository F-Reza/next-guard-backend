<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration
{

    public function up(): void
    {

        Schema::create('admin_notifications', function (Blueprint $table) {


            $table->id();


            $table->foreignId('admin_id')
                ->constrained()
                ->cascadeOnDelete();



            $table->string('type');


            $table->string('title');


            $table->text('message');



            $table->boolean('is_read')
                ->default(false);



            $table->json('metadata')
                ->nullable();



            $table->timestamps();


        });

    }



    public function down(): void
    {

        Schema::dropIfExists('admin_notifications');

    }

};