<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'Admin Panel'); ?> - Next Guard
    </title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

</head>

<body>

<aside
    class="admin-sidebar offcanvas-lg offcanvas-start"
    tabindex="-1"
    id="adminSidebar"
>

    <div class="admin-brand">

        <div>

            <div class="admin-brand-title">
                Next Guard
            </div>

            <div class="admin-brand-subtitle">
                ADMIN CONTROL PANEL
            </div>

        </div>

    </div>


    <div class="offcanvas-body">

        <nav class="admin-nav">

            <div class="small text-uppercase text-secondary px-3 mb-2">
                Main
            </div>


            <a
                href="<?php echo e(route('admin.dashboard')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
            >
                <i class="bi bi-speedometer2"></i>
                Dashboard
            </a>


            <?php if(
                $admin->role === 'super_admin'
                ||
                $admin->permissions->contains('name', 'manage_users')
            ): ?>

                <a
                    href="<?php echo e(route('admin.users')); ?>"
                    class="nav-link <?php echo e(request()->routeIs('admin.users*') ? 'active' : ''); ?>"
                >
                    <i class="bi bi-people"></i>
                    Users
                </a>

            <?php endif; ?>


            <?php if(
                $admin->role === 'super_admin'
                ||
                $admin->permissions->contains('name', 'manage_plans')
            ): ?>

                <a href="#" class="nav-link">
                    <i class="bi bi-box-seam"></i>
                    Plans
                </a>

            <?php endif; ?>


            <?php if(
                $admin->role === 'super_admin'
                ||
                $admin->permissions->contains('name', 'manage_subscriptions')
            ): ?>

                <a href="#" class="nav-link">
                    <i class="bi bi-credit-card"></i>
                    Subscriptions
                </a>

            <?php endif; ?>


            <?php if(
                $admin->role === 'super_admin'
                ||
                $admin->permissions->contains('name', 'manage_licenses')
            ): ?>

                <a href="#" class="nav-link">
                    <i class="bi bi-key"></i>
                    Licenses
                </a>

            <?php endif; ?>


            <div class="small text-uppercase text-secondary px-3 mt-4 mb-2">
                Security
            </div>


            <?php if(
                $admin->role === 'super_admin'
                ||
                $admin->permissions->contains('name', 'view_logs')
            ): ?>

                <a href="#" class="nav-link">
                    <i class="bi bi-journal-text"></i>
                    Activity Logs
                </a>

            <?php endif; ?>


            <?php if($admin->role === 'super_admin'): ?>

                <a href="#" class="nav-link">
                    <i class="bi bi-shield-lock"></i>
                    Admin Management
                </a>

            <?php endif; ?>


            <a href="#" class="nav-link">
                <i class="bi bi-bell"></i>
                Notifications
            </a>

        </nav>

    </div>

</aside>


<div class="admin-main">

    <nav class="admin-topbar navbar px-3 px-lg-4">

        <button
            class="btn btn-outline-secondary d-lg-none me-2"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#adminSidebar"
        >
            <i class="bi bi-list"></i>
        </button>


        <span class="navbar-brand fw-semibold mb-0">
            <?php echo $__env->yieldContent('page_title', 'Dashboard'); ?>
        </span>


        <div class="ms-auto dropdown">

            <button
                class="btn btn-light dropdown-toggle"
                data-bs-toggle="dropdown"
                type="button"
            >

                <i class="bi bi-person-circle me-1"></i>

                <?php echo e($admin->name); ?>


            </button>


            <ul class="dropdown-menu dropdown-menu-end">

                <li>
                    <span class="dropdown-item-text">

                        <strong>
                            <?php echo e($admin->name); ?>

                        </strong>

                        <br>

                        <small class="text-muted">
                            <?php echo e($admin->role); ?>

                        </small>

                    </span>
                </li>

                <li>
                    <hr class="dropdown-divider">
                </li>

                <li>

                    <form
                        method="POST"
                        action="<?php echo e(route('admin.logout')); ?>"
                    >

                        <?php echo csrf_field(); ?>

                        <button
                            type="submit"
                            class="dropdown-item text-danger"
                        >
                            <i class="bi bi-box-arrow-right me-2"></i>
                            Logout
                        </button>

                    </form>

                </li>

            </ul>

        </div>

    </nav>


    <main class="container-fluid p-3 p-lg-4">

        <?php if(session('success')): ?>

            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>

        <?php endif; ?>


        <?php echo $__env->yieldContent('content'); ?>

    </main>

</div>

</body>

</html><?php /**PATH D:\BackEnd\next-guard-backend\resources\views/layouts/admin.blade.php ENDPATH**/ ?>