<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration
{

    public function up(): void
    {

        Schema::create('permissions', function (Blueprint $table) {


            $table->id();


            /*
            |--------------------------------------------------------------------------
            | Permission Name
            |--------------------------------------------------------------------------
            */

            $table->string(
                'name',
                100
            )->unique();



            /*
            |--------------------------------------------------------------------------
            | Description
            |--------------------------------------------------------------------------
            */

            $table->text(
                'description'
            )->nullable();



            $table->timestamps();


        });

    }



    public function down(): void
    {

        Schema::dropIfExists('permissions');

    }

};