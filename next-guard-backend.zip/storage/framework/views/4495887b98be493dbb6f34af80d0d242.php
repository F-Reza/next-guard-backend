<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Admin Login - Next Guard</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

</head>

<body>

<div class="login-page d-flex align-items-center justify-content-center p-3">

    <div class="card login-card w-100">

        <div class="card-body p-4 p-md-5">

            <div class="text-center mb-4">

                <div class="fw-bold fs-3">
                    Next Guard
                </div>

                <div class="text-muted">
                    Admin Control Panel
                </div>

            </div>


            <?php if(session('error')): ?>

                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>

            <?php endif; ?>


            <?php if(session('success')): ?>

                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>


            <?php if($errors->any()): ?>

                <div class="alert alert-danger">

                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div><?php echo e($error); ?></div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <?php endif; ?>


            <form
                method="POST"
                action="<?php echo e(route('admin.login.submit')); ?>"
            >

                <?php echo csrf_field(); ?>


                <div class="mb-3">

                    <label
                        for="email"
                        class="form-label"
                    >
                        Email
                    </label>

                    <input
                        type="email"
                        class="form-control form-control-lg"
                        id="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="email"
                        required
                        autofocus
                    >

                </div>


                <div class="mb-4">

                    <label
                        for="password"
                        class="form-label"
                    >
                        Password
                    </label>

                    <input
                        type="password"
                        class="form-control form-control-lg"
                        id="password"
                        name="password"
                        autocomplete="current-password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn btn-primary btn-lg w-100"
                >
                    <i class="bi bi-box-arrow-in-right me-1"></i>
                    Sign In
                </button>

            </form>

        </div>

    </div>

</div>

</body>

</html><?php /**PATH D:\BackEnd\next-guard-backend\resources\views/admin/login.blade.php ENDPATH**/ ?>