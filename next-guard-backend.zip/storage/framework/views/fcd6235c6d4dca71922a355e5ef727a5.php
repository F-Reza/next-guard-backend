

<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('page_title', 'User Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

    <div>

        <h1 class="h3 mb-1">
            User Details
        </h1>

        <p class="text-muted mb-0">
            View account information.
        </p>

    </div>


    <div class="d-flex gap-2">

        <a
            href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
            class="btn btn-primary"
        >
            <i class="bi bi-pencil me-1"></i>
            Edit
        </a>


        <form
            method="POST"
            action="<?php echo e(route('admin.users.destroy', $user->id)); ?>"
            onsubmit="return confirm('Are you sure you want to delete this user?');"
        >

            <?php echo csrf_field(); ?>

            <?php echo method_field('DELETE'); ?>

            <button
                type="submit"
                class="btn btn-outline-danger"
            >
                <i class="bi bi-trash me-1"></i>
                Delete
            </button>

        </form>


        <a
            href="<?php echo e(route('admin.users')); ?>"
            class="btn btn-outline-secondary"
        >
            <i class="bi bi-arrow-left me-1"></i>
            Back
        </a>

    </div>

</div>


<div class="row g-4">

    

    <div class="col-lg-8">

        <div class="card border-0 shadow-sm">

            <div class="card-header bg-white py-3">

                <div class="fw-semibold">
                    Account Information
                </div>

            </div>


            <div class="card-body">

                <div class="row g-4">

                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            User ID
                        </div>

                        <div class="fw-semibold">
                            #<?php echo e($user->id); ?>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            Status
                        </div>

                        <?php if($user->status === 'active'): ?>

                            <span class="badge text-bg-success">
                                Active
                            </span>

                        <?php elseif($user->status === 'inactive'): ?>

                            <span class="badge text-bg-secondary">
                                Inactive
                            </span>

                        <?php else: ?>

                            <span class="badge text-bg-warning">
                                <?php echo e(ucfirst($user->status)); ?>

                            </span>

                        <?php endif; ?>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            Name
                        </div>

                        <div class="fw-semibold">
                            <?php echo e($user->name); ?>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            Email
                        </div>

                        <div>

                            <?php echo e($user->email ?: '—'); ?>


                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            Phone
                        </div>

                        <div>

                            <?php echo e($user->phone ?: '—'); ?>


                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small mb-1">
                            Registered
                        </div>

                        <div>

                            <?php echo e($user->created_at?->format('Y-m-d H:i:s')); ?>


                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    

    <div class="col-lg-4">

        <div class="card border-0 shadow-sm">

            <div class="card-header bg-white py-3">

                <div class="fw-semibold">
                    Verification
                </div>

            </div>


            <div class="card-body">


                <div class="d-flex justify-content-between align-items-center mb-3">

                    <span>
                        Email
                    </span>

                    <?php if($user->email_verified_at): ?>

                        <span class="badge text-bg-success">
                            Verified
                        </span>

                    <?php else: ?>

                        <span class="badge text-bg-secondary">
                            Not Verified
                        </span>

                    <?php endif; ?>

                </div>


                <div class="d-flex justify-content-between align-items-center">

                    <span>
                        Phone
                    </span>

                    <?php if($user->phone_verified_at): ?>

                        <span class="badge text-bg-success">
                            Verified
                        </span>

                    <?php else: ?>

                        <span class="badge text-bg-secondary">
                            Not Verified
                        </span>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>


    

    <div class="col-12">

        <div class="card border-0 shadow-sm">

            <div class="card-header bg-white py-3">

                <div class="fw-semibold">
                    Account Timeline
                </div>

            </div>


            <div class="card-body">

                <div class="row g-4">

                    <div class="col-md-6">

                        <div class="text-muted small">
                            Created At
                        </div>

                        <div class="fw-semibold">

                            <?php echo e($user->created_at?->format('Y-m-d H:i:s')); ?>


                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="text-muted small">
                            Updated At
                        </div>

                        <div class="fw-semibold">

                            <?php echo e($user->updated_at?->format('Y-m-d H:i:s')); ?>


                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BackEnd\next-guard-backend\resources\views/admin/users/show.blade.php ENDPATH**/ ?>