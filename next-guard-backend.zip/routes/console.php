<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use App\Jobs\RetryFailedProtectionSync;
use Illuminate\Support\Facades\Schedule;


Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');


Schedule::job(
    new RetryFailedProtectionSync()
)
->everyFiveMinutes();

Schedule::command(
    'subscriptions:expire'
)
->daily();