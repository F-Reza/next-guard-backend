

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('page_title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

    <div>
        <h1 class="h3 mb-1">
            Users
        </h1>

        <p class="text-muted mb-0">
            Manage registered users.
        </p>
    </div>


    <div class="d-flex align-items-center gap-2">

        <span class="badge text-bg-primary fs-6">
            <?php echo e($users->total()); ?> Users
        </span>

        <a
            href="<?php echo e(route('admin.users.create')); ?>"
            class="btn btn-primary"
        >
            <i class="bi bi-person-plus me-1"></i>
            Add User
        </a>

    </div>

</div>




<div class="card border-0 shadow-sm mb-4">

    <div class="card-body">

        <form
            method="GET"
            action="<?php echo e(route('admin.users')); ?>"
            class="row g-3"
        >

            <div class="col-md-6">

                <label class="form-label">
                    Search
                </label>

                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Name, email or phone"
                    value="<?php echo e(request('search')); ?>"
                >

            </div>


            <div class="col-md-3">

                <label class="form-label">
                    Status
                </label>

                <select
                    name="status"
                    class="form-select"
                >

                    <option value="">
                        All Status
                    </option>

                    <option
                        value="active"
                        <?php if(request('status') === 'active'): echo 'selected'; endif; ?>
                    >
                        Active
                    </option>

                    <option
                        value="inactive"
                        <?php if(request('status') === 'inactive'): echo 'selected'; endif; ?>
                    >
                        Inactive
                    </option>

                </select>

            </div>


            <div class="col-md-3 d-flex align-items-end gap-2">

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    <i class="bi bi-search me-1"></i>
                    Search
                </button>


                <a
                    href="<?php echo e(route('admin.users')); ?>"
                    class="btn btn-outline-secondary"
                >
                    Reset
                </a>

            </div>

        </form>

    </div>

</div>


<?php if($users->isEmpty()): ?>

    <div class="card border-0 shadow-sm">

        <div class="card-body text-center py-5">

            <i class="bi bi-people fs-1 text-muted"></i>

            <h5 class="mt-3">
                No users found
            </h5>

            <p class="text-muted">
                No users match your current search.
            </p>

            <a
                href="<?php echo e(route('admin.users.create')); ?>"
                class="btn btn-primary"
            >
                <i class="bi bi-person-plus me-1"></i>
                Add First User
            </a>

        </div>

    </div>

<?php else: ?>

    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white py-3">

            <div class="fw-semibold">
                Registered Users
            </div>

        </div>


        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                    <tr>

                        <th class="px-4">
                            ID
                        </th>

                        <th>
                            Name
                        </th>

                        <th>
                            Email
                        </th>

                        <th>
                            Phone
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Registered
                        </th>

                        <th class="text-end px-4">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td class="px-4 fw-semibold">
                                #<?php echo e($user->id); ?>

                            </td>


                            <td>

                                <div class="fw-semibold">
                                    <?php echo e($user->name); ?>

                                </div>

                            </td>


                            <td>
                                <?php echo e($user->email ?: '—'); ?>

                            </td>


                            <td>
                                <?php echo e($user->phone ?: '—'); ?>

                            </td>


                            <td>

                                <?php if($user->status === 'active'): ?>

                                    <span class="badge text-bg-success">
                                        Active
                                    </span>

                                <?php else: ?>

                                    <span class="badge text-bg-secondary">
                                        <?php echo e(ucfirst($user->status)); ?>

                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <span class="text-muted">

                                    <?php echo e($user->created_at?->format('Y-m-d H:i')); ?>


                                </span>

                            </td>


                            <td class="text-end px-4">

                                <div class="btn-group">

                                    <a
                                        href="<?php echo e(route('admin.users.show', $user->id)); ?>"
                                        class="btn btn-sm btn-outline-primary"
                                        title="View"
                                    >
                                        <i class="bi bi-eye"></i>
                                    </a>


                                    <a
                                        href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                        class="btn btn-sm btn-outline-secondary"
                                        title="Edit"
                                    >
                                        <i class="bi bi-pencil"></i>
                                    </a>


                                    <form
                                        method="POST"
                                        action="<?php echo e(route('admin.users.destroy', $user->id)); ?>"
                                        onsubmit="return confirm('Are you sure you want to delete this user?');"
                                    >

                                        <?php echo csrf_field(); ?>

                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-danger"
                                            title="Delete"
                                        >
                                            <i class="bi bi-trash"></i>
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

        </div>


        <?php if($users->hasPages()): ?>

            <div class="card-footer bg-white">

                <?php echo e($users->links()); ?>


            </div>

        <?php endif; ?>

    </div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BackEnd\next-guard-backend\resources\views/admin/users/index.blade.php ENDPATH**/ ?>