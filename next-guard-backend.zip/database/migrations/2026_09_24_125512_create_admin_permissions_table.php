<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


return new class extends Migration
{

    public function up(): void
    {

        Schema::create('admin_permissions', function (Blueprint $table) {


            $table->id();



            /*
            |--------------------------------------------------------------------------
            | Admin
            |--------------------------------------------------------------------------
            */

            $table->foreignId('admin_id')
                ->constrained('admins')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();



            /*
            |--------------------------------------------------------------------------
            | Permission
            |--------------------------------------------------------------------------
            */

            $table->foreignId('permission_id')
                ->constrained('permissions')
                ->cascadeOnUpdate()
                ->cascadeOnDelete();



            $table->timestamps();



            $table->unique([
                'admin_id',
                'permission_id'
            ]);


        });

    }



    public function down(): void
    {

        Schema::dropIfExists('admin_permissions');

    }

};